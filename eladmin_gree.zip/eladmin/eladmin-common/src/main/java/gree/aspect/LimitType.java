package gree.aspect;

public enum LimitType {
    CUSTOMER,
//     by ip addr
    IP;
}
